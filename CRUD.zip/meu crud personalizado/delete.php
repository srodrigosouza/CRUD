<?php
include 'db_connect.php'; // Conexão com o banco de dados

// Verificar se o ID foi passado via URL
if (isset($_GET['id'])) {
    $userId = $_GET['id'];
    $errorMessage = ''; // Variável para armazenar a mensagem de erro

    // Verifica se o formulário foi enviado
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $senha = $_POST['senha'];

        // Recuperar a senha do usuário do banco de dados para comparação
        $sql = "SELECT senha FROM usuarios WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($storedPassword);
        $stmt->fetch();

        // Verificar se a senha fornecida corresponde à senha armazenada no banco
        if (password_verify($senha, $storedPassword)) {
            // Se a senha estiver correta, exclui o usuário
            $deleteSql = "DELETE FROM usuarios WHERE id = ?";
            $deleteStmt = $conn->prepare($deleteSql);
            $deleteStmt->bind_param("i", $userId);
            if ($deleteStmt->execute()) {
                header("Location: index.php?msg=Usuário excluído com sucesso");
                exit;
            } else {
                echo "Erro ao excluir o usuário.";
            }
        } else {
            $errorMessage = "Senha incorreta. Tente novamente."; // Mensagem de erro
        }
    }
} else {
    echo "Usuário não encontrado.";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmar Exclusão</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Confirmar Exclusão</h2>

        <!-- Exibir a mensagem de erro, se houver -->
        <?php if (!empty($errorMessage)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $errorMessage; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="senha" class="form-label">Senha</label>
                <input type="password" class="form-control" id="senha" name="senha" required>
            </div>

            <!-- Botões de confirmação e cancelamento -->
            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-danger me-2">Confirmar Exclusão</button>
                <button type="button" class="btn btn-secondary" onclick="window.location.href='index.php';">Cancelar</button>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
<footer class="text-center mt-5">
    <p>&copy; 2025 Rodrigo Souza. Todos os direitos reservados.</p>
</footer>
</html>

<?php
include 'db_connect.php'; // Conexão com o banco de dados

// Verificar se o ID foi passado na URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Preparar a consulta para buscar o registro específico
    $sql = "SELECT id, nome, email, data_nascimento FROM usuarios WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id); // "i" indica que o ID é um inteiro
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id_usuario, $nome, $email, $data_nascimento);

    if ($stmt->fetch()) {
        // Formatar a data de nascimento para o formato "dia/mês/ano"
        $data_nascimento_formatada = date("d/m/Y", strtotime($data_nascimento));
    } else {
        echo "Usuário não encontrado.";
    }

    $stmt->close();
} else {
    echo "ID não fornecido.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar Registro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Detalhes do Registro</h2>

        <!-- Exibir os dados -->
        <div class="mb-3">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" class="form-control" id="nome" value="<?php echo htmlspecialchars($nome); ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" value="<?php echo htmlspecialchars($email); ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="data_nascimento" class="form-label">Data de Nascimento</label>
            <input type="text" class="form-control" id="data_nascimento" value="<?php echo htmlspecialchars($data_nascimento_formatada); ?>" readonly>
        </div>

        <a href="index.php" class="btn btn-secondary">Voltar</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
<footer class="text-center mt-5">
    <p>&copy; 2025 Rodrigo Souza. Todos os direitos reservados.</p>
</footer>
</html>

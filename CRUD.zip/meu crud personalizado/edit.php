<?php
// Conectar ao banco de dados
include 'db_connect.php';

// Variáveis para mensagem de sucesso
$successMessage = "";
$errorMessage = "";

// Verificar se o ID foi passado pela URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Buscar o registro do banco de dados
    $sql = "SELECT * FROM usuarios WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Pega os dados do usuário
        $row = $result->fetch_assoc();
        $nome = $row['nome'];
        $email = $row['email'];
        $data_nascimento = $row['data_nascimento']; // Asegure-se de que a tabela tenha esse campo
        $senha_armazenada = $row['senha']; // Senha armazenada no banco
    } else {
        echo "Registro não encontrado!";
        exit;
    }
} else {
    echo "ID não fornecido!";
    exit;
}

// Verificar se o formulário foi enviado para atualizar o registro
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capturar os dados do formulário
    $novo_nome = $_POST['nome'];
    $novo_email = $_POST['email'];
    $nova_data_nascimento = $_POST['data_nascimento'];
    $senha_digitada = $_POST['senha']; // Senha inserida pelo usuário

    // Verificar se a senha digitada corresponde à senha armazenada
    if (password_verify($senha_digitada, $senha_armazenada)) {
        // Atualizar o registro no banco de dados
        $sql_update = "UPDATE usuarios SET nome = ?, email = ?, data_nascimento = ? WHERE id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("sssi", $novo_nome, $novo_email, $nova_data_nascimento, $id);

        if ($stmt_update->execute()) {
            // Definir mensagem de sucesso
            $successMessage = "Registro atualizado com sucesso!";
        } else {
            $errorMessage = "Erro ao atualizar o registro!";
        }
    } else {
        $errorMessage = "Senha incorreta! Atualização não realizada.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Registro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Editar Registro</h2>

        <?php if ($successMessage): ?>
            <div class="alert alert-success" role="alert" id="successMessage">
                <?php echo $successMessage; ?>
            </div>
        <?php elseif ($errorMessage): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $errorMessage; ?>
            </div>
        <?php endif; ?>

        <!-- Formulário para editar -->
        <form id="formEdit" method="POST">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome</label>
                <input type="text" class="form-control" id="nome" name="nome" value="<?php echo htmlspecialchars($nome); ?>" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            <div class="mb-3">
                <label for="data_nascimento" class="form-label">Data de nascimento</label>
                <input type="date" class="form-control" id="data_nascimento" name="data_nascimento" value="<?php echo htmlspecialchars($data_nascimento); ?>" required>
            </div>
            <button type="button" class="btn btn-primary" id="updateButton">Atualizar</button>
            <a href="index.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>

    <!-- Modal para confirmar senha -->
    <div class="modal fade" id="senhaModal" tabindex="-1" aria-labelledby="senhaModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="senhaModalLabel">Verificação de Senha</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <label for="senha" class="form-label">Digite sua senha para continuar:</label>
                    <input type="password" class="form-control" id="senha" name="senha" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="confirmButton">Confirmar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS e dependências -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Ao clicar no botão "Atualizar", abre o modal para confirmar a senha
        document.getElementById("updateButton").addEventListener("click", function () {
            var myModal = new bootstrap.Modal(document.getElementById('senhaModal'));
            myModal.show();
        });

        // Ao clicar em "Confirmar" no modal, valida a senha e envia o formulário
        document.getElementById("confirmButton").addEventListener("click", function () {
            var senha = document.getElementById("senha").value;

            // Verifica se a senha foi preenchida
            if (senha.trim() === "") {
                alert("A senha é obrigatória!");
                return;
            }

            // Atribui a senha ao campo do formulário
            var senhaField = document.createElement('input');
            senhaField.type = 'hidden';
            senhaField.name = 'senha';
            senhaField.value = senha;
            document.getElementById("formEdit").appendChild(senhaField);

            // Envia o formulário
            document.getElementById("formEdit").submit();
        });

        // Redirecionar para a página "index.php" após 3 segundos, se houver mensagem de sucesso
        <?php if ($successMessage): ?>
            setTimeout(function() {
                window.location.href = "index.php";
            }, 3000); // Redireciona após 3 segundos
        <?php endif; ?>
    </script>
</body>
<footer class="text-center mt-5">
    <p>&copy; 2025 Rodrigo Souza. Todos os direitos reservados.</p>
</footer>
</html>

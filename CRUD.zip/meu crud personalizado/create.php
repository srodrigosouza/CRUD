<?php
include 'db_connect.php'; // Conexão com o banco de dados

// Variável para controlar o sucesso da operação
$success = false;

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obter os dados do formulário
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $data_nascimento = $_POST['data_nascimento'];
    $senha = $_POST['senha'];

    // Gerar o hash da senha
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);  // Cria o hash da senha

    // Prevenir injeção de SQL com prepared statements
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, data_nascimento, senha) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nome, $email, $data_nascimento, $senha_hash); // Usar o hash da senha em vez da senha simples

    if ($stmt->execute()) {
        $success = true; // Definir sucesso como true para exibir o modal
    } else {
        echo "Erro: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Novo Registro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Adicionar Novo Registro</h2>

        <form method="POST" action="create.php">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome</label>
                <input type="text" class="form-control" id="nome" name="nome" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="data_nascimento" class="form-label">Data de Nascimento</label>
                <input type="date" class="form-control" id="data_nascimento" name="data_nascimento" required>
            </div>
            <div class="mb-3">
                <label for="senha" class="form-label">Senha</label>
                <input type="password" class="form-control" id="senha" name="senha" required>
            </div>
            <button type="submit" class="btn btn-success">Adicionar</button>
            <a href="index.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>

    <!-- Modal de Sucesso -->
    <div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="successModalLabel">Sucesso!</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    O registro foi adicionado com sucesso!
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal" id="redirectButton">OK</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        <?php if ($success): ?>
            // Mostrar o modal de sucesso
            var myModal = new bootstrap.Modal(document.getElementById('successModal'));
            myModal.show();

            // Redirecionar após o clique no botão "OK"
            document.getElementById('redirectButton').addEventListener('click', function() {
                window.location.href = 'index.php';
            });
        <?php endif; ?>
    </script>

    <!-- Rodapé -->
    <footer class="text-center mt-5">
        <p>&copy; 2025 Rodrigo Souza. Todos os direitos reservados.</p>
    </footer>
</body>
</html>

<?php
include 'db_connect.php'; // Conexão com o banco de dados
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Básico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Gerenciamento de Registros</h2>

        <!-- Botão Adicionar Novo -->
        <div class="d-flex justify-content-end mb-3">
            <a href="create.php" class="btn btn-success">Adicionar Novo</a>
        </div>

        <!-- Tabela de Registros -->
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Data de Nascimento</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Conexão com o banco de dados (substitua pelos seus dados)
                $conn = new mysqli("localhost", "root", "", "meucrudpersonalizado");

                // Verifica conexão
                if ($conn->connect_error) {
                    die("Falha na conexão: " . $conn->connect_error);
                }

                // Busca os registros
                $sql = "SELECT id, nome, email, data_nascimento FROM usuarios";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['nome'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "<td>" . date('d/m/Y', strtotime($row['data_nascimento'])) . "</td>"; // Exibe a data no formato 'dd/mm/yyyy'
                        echo "<td>
                                <a href='view.php?id=" . $row['id'] . "' class='btn btn-info btn-sm'>👁 Visualizar</a>
                                <a href='edit.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>✏ Editar</a>
                                <a href='delete.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm'>🗑 Excluir</a>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center'>Nenhum registro encontrado</td></tr>";
                }

                $conn->close();
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
<!-- assinatura -->
<footer class="text-center mt-5">
    <p>&copy; 2025 Rodrigo Souza. Todos os direitos reservados.</p>
</footer>
</html>

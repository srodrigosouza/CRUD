<?php
$servername = "localhost";  // Servidor (normalmente "localhost")
$username = "root";         // Usuário do banco de dados
$password = "";             // Senha (deixe vazio se não tiver)
$database = "meucrudpersonalizado";    // Nome do banco de dados

// Criar conexão
$conn = new mysqli($servername, $username, $password, $database);

// Verificar conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
?>
